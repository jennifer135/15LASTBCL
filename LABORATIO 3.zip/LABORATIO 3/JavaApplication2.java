/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       double x;
       double y;
       
       
       System.out.println("ingresar la siguiente cantidad");
       Scanner D1.new Scanner(System.in);
       
       x = D1.nextln();
       
       y = 15 + X = 120;
       
    }
    
}
